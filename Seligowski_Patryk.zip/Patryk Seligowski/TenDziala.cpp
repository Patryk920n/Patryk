#include <iostream>
#include <vector>
#include <queue>
#include <cmath>
#include <algorithm>
#include <fstream>

using namespace std;

struct Point {
    int x, y;
    double f, g, h;

    Point(int x, int y) : x(x), y(y), f(0), g(0), h(0) {}

    void calculateF() {
        f = g + h;
    }
};

class Grid {
public:
    vector<vector<int> > grid;
    int rows, cols;

    Grid(int rows, int cols) : rows(rows), cols(cols) {
        grid.resize(rows, vector<int>(cols, 0));
    }

    bool isValid(int x, int y) const {
        return x >= 0 && x < rows && y >= 0 && y < cols;
    }

    bool isFree(int x, int y) const {
        return isValid(x, y) && grid[x][y] == 0;
    }
};

vector<Point> AStar(const Grid& grid, const Point& start, const Point& goal) {
    queue<Point> openSet;
    openSet.push(start);

    vector<vector<Point> > cameFrom(grid.rows, vector<Point>(grid.cols, Point(-1, -1)));
    vector<vector<double> > gScore(grid.rows, vector<double>(grid.cols, INFINITY));
    gScore[start.x][start.y] = 0;

    vector<vector<double> > hScore(grid.rows, vector<double>(grid.cols, 0));
    for (int x = 0; x < grid.rows; ++x) {
        for (int y = 0; y < grid.cols; ++y) {
            hScore[x][y] = sqrt(pow(goal.x - x, 2) + pow(goal.y - y, 2));
        }
    }

    while (!openSet.empty()) {
        Point current = openSet.front();
        openSet.pop();

        if (current.x == goal.x && current.y == goal.y) {
            vector<Point> path;
            while (current.x != -1 && current.y != -1) {
                path.push_back(current);
                current = cameFrom[current.x][current.y];
            }
            reverse(path.begin(), path.end());
            return path;
        }

        // Mo�emy przemieszcza� si� tylko o 1 jednostk� wzd�u� osi x lub y
        int dx_values[] = {-1, 0, 1, 0};
        int dy_values[] = {0, -1, 0, 1};

        for (int i = 0; i < 4; ++i) {
            int neighborX = current.x + dx_values[i];
            int neighborY = current.y + dy_values[i];

            if (!grid.isValid(neighborX, neighborY) || !grid.isFree(neighborX, neighborY)) continue;

            double tentativeGScore = gScore[current.x][current.y] + 1; // Koszt przemieszczenia si� o 1 jednostk�

            if (tentativeGScore < gScore[neighborX][neighborY]) {
                cameFrom[neighborX][neighborY] = current;
                gScore[neighborX][neighborY] = tentativeGScore;
                Point neighbor(neighborX, neighborY);
                neighbor.g = gScore[neighborX][neighborY];
                neighbor.h = hScore[neighborX][neighborY];
                neighbor.calculateF();
                openSet.push(neighbor);
            }
        }
    }

    return {};
}

int main() {
	Grid grid(20, 20);
	//===============Wczytywanie==============
	cout<<"Wczytywanie danych z pliku\n";

string nazwap="grid.txt";
int wym2=20;
int wym1=20;

//teraz deklarujemy dynamicznie tablice do, kt�rej wczytamyu nasz plik,
int rows = wym2+1;
double **G;
G = new double*[rows];
while(rows--) G[rows] = new double[wym1+1];

cout<<"\n\nNacisnij ENTER aby wczytac tablice o nazwie "<< nazwap;
getchar();

std::ifstream plik(nazwap.c_str());
  
for ( unsigned int i=1;i<wym2+1;i++)    
  {
    for ( unsigned int j=1;j<wym1+1;j++) 
    {
         plik >> G[i][j];
    }
  }  
plik.close();

cout<<"\nWypisujemy na ekran\n\n";
for(int i=1;i<wym2+1;i++)
 {
  for(int j=1;j<wym1+1;j++)
   {
    cout<<" "<<G[i][j];
    if(G[i][j]==5){
    	grid.grid[i-1][j-1]=5;
	}
//    grid.grid[i][j]=G[i][j];
   }cout<<"\n";
 }
   
//na koniec czy�cimy pami�� po naszej tablicy
for(int i=0;i<wym2+1;i++)
{delete[] G[i];}//czyscimy wiersze
delete[] G;//zwalniamy tablice wskaznikow do wierszy

cout<<"\n\nNacisnij ENTER aby zakonczyc";
getchar();
	//================

   
    Point start(0, 0);
    Point goal(19, 19);

//    grid.grid[1][2] = 5;
//    grid.grid[2][2] = 5;
//    grid.grid[3][2] = 5;
//    grid.grid[4][2] = 5;
//    grid.grid[5][2] = 5;
//    grid.grid[6][2] = 5;
//	grid.grid[0][0] = 5;
//	grid.grid[19][19] = 5;
	if(!(grid.isFree(start.x,start.y))){
		cout << "bledny start" << endl;
	}
	else{
		vector<Point> path = AStar(grid, start, goal);

    	if (!path.empty()) {
        	cout << "Znaleziona sciezka:" << endl;
        	for (size_t i = 0; i < path.size(); ++i) {
            	cout << "(" << path[i].x << ", " << path[i].y << ") ";
            	grid.grid[path[i].x][path[i].y]=3;
        	}
        	cout << endl;
    	} else {
        	cout << "Nie udalo sie znalezc sciezki." << endl;
    	}
		for (int i = 0; i < 20; ++i) {
	    	    for (int j = 0; j < 20; ++j) {
	        	    cout << grid.grid[i][j] << " ";
	        	}
	        	cout << endl;
	    	}
	}
    return 0;
}

